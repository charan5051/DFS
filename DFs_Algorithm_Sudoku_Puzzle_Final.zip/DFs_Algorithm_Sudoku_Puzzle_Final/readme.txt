Sudoku Puzzle Solver Using DFs Backtracking Method:

Tools Used:
IDE - CodeBlocks 

Required Modules:
OpenCV - Needs to be installed and then compiled it using CMake. 
Then update the OpenCV dll files, include folder paths in your IDE compiler and Linker settings.

Please find the more info here - https://www.kevinhughes.ca/tutorials/opencv-install-on-windows-with-codeblocks-and-mingw

Affere successfully Updation of OPENCV paths in compiler,
1. Load the Prject which is present under - Sudoku_Solver_with_OpenCV in CodeBlock IDE
2. Then it will load all the required header files and Souce code to IDE
3. After this you can just give Build and RUN.
4. Then you will observe the output SUDOKU Puzzle in GUI. It will contains 3 test datas.
5. You can select any one and give run. So that backtarack algorihhm will solve it and dispay the results
6. Here you can provide dynamic inpus also during runtime by using keyboard and mouse.


Note:
If you were not able to install OpenCV. Here we have provided optional code "Sudoku_Solve"

This is also contains the same algorithm with same functionality and same test data. Only differenc is its not used OpenCV for GUI
So in this case, you can directly execute the sudoku_solver.cpp file which is present under sudoku_solver Folder.

It will solve the Sudoku Puzzle which we provided statically inside the code and displays the solved Sudoku Puzzle in console.

Thank you